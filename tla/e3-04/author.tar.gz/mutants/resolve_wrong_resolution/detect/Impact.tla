---- MODULE Impact ----
EXTENDS Integers, Sequences, FiniteSets, TLC
Seed == [current_release |-> 1, items |-> [a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> TRUE, type |-> "AT", version |-> 1], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "AT", version |-> 1], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> TRUE, type |-> "CODE", version |-> 1], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "DES", version |-> 1], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "PLAN", version |-> 1], r1 |-> [depends_on |-> {"p1"}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "REQ", version |-> 2], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "REQ", version |-> 1], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]], next_release_required |-> FALSE, questions |-> [q0 |-> [about |-> "r1", about_version |-> 1, age |-> 1, blocking |-> TRUE, consumed |-> TRUE, id |-> "q0", kind |-> "change", requested_transition |-> "T05", resolution |-> "approved", state |-> "resolved"], q1 |-> [about |-> "a1", about_version |-> 1, age |-> 2, blocking |-> TRUE, consumed |-> FALSE, id |-> "q1", kind |-> "change", requested_transition |-> "T05", resolution |-> "none", state |-> "asked"]], releases |-> ((1 :> [acceptance |-> "__null__", number |-> 1, scope |-> {"a1", "a2", "c1", "d1", "p1", "r1", "r2"}, snapshot |-> "__null__", state |-> "in_preparation"]))]
Types == [AT |-> [depends_on |-> {"REQ"}, requires_approval |-> TRUE], CODE |-> [depends_on |-> {"AT", "DES"}, requires_approval |-> FALSE], DES |-> [depends_on |-> {"REQ"}, requires_approval |-> FALSE], PLAN |-> [depends_on |-> {}, requires_approval |-> TRUE], REQ |-> [depends_on |-> {"PLAN"}, requires_approval |-> TRUE]]
Closure == [a1 |-> {"c1"}, a2 |-> {}, c1 |-> {}, d1 |-> {"c1"}, p1 |-> {"a1", "a2", "c1", "d1", "r1", "r2", "r3"}, r1 |-> {"a1", "c1", "d1"}, r2 |-> {"a2"}, r3 |-> {}]
ChangeOperations == {"T05", "T07"}
NoneItem == [depends_on |-> {}, id |-> "none", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "none", version |-> 0]
Lookup(w,id) == IF id = "none" THEN NoneItem ELSE w.items[id]
NextAge(w) == IF DOMAIN w.questions = {} THEN 1 ELSE 1 + (CHOOSE n \in {w.questions[q].age : q \in DOMAIN w.questions}: \A q \in DOMAIN w.questions: w.questions[q].age <= n)
SelectQuestion(w,state,newest) == LET qs == {w.questions[z] : z \in {i \in DOMAIN w.questions: w.questions[i].state = state}} IN IF qs = {} THEN "__null__" ELSE CHOOSE q \in qs: \A p \in qs: (q.blocking \/ ~p.blocking) /\ ((q.blocking = p.blocking) => (IF newest THEN q.age >= p.age ELSE q.age <= p.age))
Invalidate(w,id) == LET r == w.releases[w.current_release] IN IF id \notin r.scope THEN w ELSE IF r.state \in {"ready", "reviewed"} THEN [w EXCEPT !.releases[w.current_release].state = "in_preparation"] ELSE IF r.state = "accepted" THEN [w EXCEPT !.next_release_required = TRUE] ELSE w
Enabled0(w,c) == IF c.item \in DOMAIN w.items THEN (~w.next_release_required) /\ (c.actor \in {"A"}) /\ (w.items[c.item].state \in {"draft"}) /\ (((~(w.items[c.item].suspect) /\ c.checks) /\ (\A bound_d \in {w.items[z] : z \in (w.items[c.item]).depends_on}: ((bound_d).state \in {"approved", "baselined"})))) ELSE FALSE
Result0(w,c) == LET s0 == [w EXCEPT !.items[c.item].state = "verified"]
    r0 == <<>>
    newSuspect == {s0.items[z] : z \in {i \in DOMAIN w.items: s0.items[i].suspect /\ ~w.items[i].suspect}}
    s1 == IF (((s0.releases[s0.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s0.releases[s0.current_release].scope))) THEN [s0 EXCEPT !.next_release_required = TRUE] ELSE s0
    r1 == r0
    s2 == IF (((s1.releases[s1.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.releases[s1.current_release].state = "in_preparation"] ELSE s1
    r2 == r1
 IN [world |-> s2, records |-> r2]
Enabled1(w,c) == IF c.item \in DOMAIN w.items THEN (~w.next_release_required) /\ (c.actor \in {"U"}) /\ (w.items[c.item].state \in {"verified"}) /\ (((Types[(w.items[c.item]).type]).requires_approval /\ ~(w.items[c.item].suspect))) /\ (c.evidence) ELSE FALSE
Result1(w,c) == LET s0 == [w EXCEPT !.items[c.item].state = "approved"]
    r0 == <<>>
    newSuspect == {s0.items[z] : z \in {i \in DOMAIN w.items: s0.items[i].suspect /\ ~w.items[i].suspect}}
    s1 == IF (((s0.releases[s0.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s0.releases[s0.current_release].scope))) THEN [s0 EXCEPT !.next_release_required = TRUE] ELSE s0
    r1 == r0
    s2 == IF (((s1.releases[s1.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.releases[s1.current_release].state = "in_preparation"] ELSE s1
    r2 == r1
 IN [world |-> s2, records |-> r2]
Enabled2(w,c) == IF c.item \in DOMAIN w.items THEN (~w.next_release_required) /\ (c.actor \in {"U"}) /\ (w.items[c.item].state \in {"approved", "verified"}) /\ (((~(w.items[c.item].suspect) /\ ((w.items[c.item].state = "approved") \/ ~((Types[(w.items[c.item]).type]).requires_approval))) /\ (\A bound_d \in {w.items[z] : z \in (w.items[c.item]).depends_on}: ((bound_d).state = "baselined")))) /\ (c.evidence) ELSE FALSE
Result2(w,c) == LET s0 == [w EXCEPT !.items[c.item].state = "baselined"]
    r0 == <<>>
    newSuspect == {s0.items[z] : z \in {i \in DOMAIN w.items: s0.items[i].suspect /\ ~w.items[i].suspect}}
    s1 == IF (((s0.releases[s0.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s0.releases[s0.current_release].scope))) THEN [s0 EXCEPT !.next_release_required = TRUE] ELSE s0
    r1 == r0
    s2 == IF (((s1.releases[s1.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.releases[s1.current_release].state = "in_preparation"] ELSE s1
    r2 == r1
 IN [world |-> s2, records |-> r2]
Enabled3(w,c) == IF c.item \in DOMAIN w.items /\ c.question \in DOMAIN w.questions THEN (~w.next_release_required) /\ (c.actor \in {"U"}) /\ (w.items[c.item].state \in {"verified", "approved", "baselined"}) /\ (((((((((w.questions[c.question]).state = "resolved") /\ ((w.questions[c.question]).kind = "change")) /\ ((w.questions[c.question]).resolution = "approved")) /\ ((w.questions[c.question]).about = (w.items[c.item]).id)) /\ ((w.questions[c.question]).about_version = (w.items[c.item]).version)) /\ ((w.questions[c.question]).requested_transition = ([id |-> "T05"]).id)) /\ ~((w.questions[c.question]).consumed))) ELSE FALSE
Result3(w,c) == LET s0 == [w EXCEPT !.items[c.item].state = "draft"]
    r0 == <<>>
    s1 == [s0 EXCEPT !.questions[c.question].consumed = TRUE]
    r1 == r0
    s2 == [s1 EXCEPT !.items[c.item].version = (s1.items[c.item].version + 1)]
    r2 == r1
    s3 == [s2 EXCEPT !.items[c.item].rejections = 0]
    r3 == r2
    s4 == [s3 EXCEPT !.items[c.item].suspect = FALSE]
    r4 == r3
    s5 == [s4 EXCEPT !.items = [z \in DOMAIN s4.items |-> IF z \in Closure[c.item] THEN [s4.items[z] EXCEPT !.suspect = TRUE] ELSE s4.items[z]]]
    r5 == r4
    s6 == Invalidate(s5, c.item)
    r6 == r5
    newSuspect == {s6.items[z] : z \in {i \in DOMAIN w.items: s6.items[i].suspect /\ ~w.items[i].suspect}}
    s7 == IF (((s6.releases[s6.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s6.releases[s6.current_release].scope))) THEN [s6 EXCEPT !.next_release_required = TRUE] ELSE s6
    r7 == r6
    s8 == IF (((s7.releases[s7.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s7.releases[s7.current_release].scope))) THEN [s7 EXCEPT !.releases[s7.current_release].state = "in_preparation"] ELSE s7
    r8 == r7
 IN [world |-> s8, records |-> r8]
Enabled4(w,c) == IF c.item \in DOMAIN w.items THEN (~w.next_release_required) /\ (c.actor \in {"A"}) /\ (w.items[c.item].state \in {"draft", "verified", "approved", "baselined"}) /\ ((w.items[c.item].suspect /\ (\A bound_d \in {w.items[z] : z \in (w.items[c.item]).depends_on}: (((bound_d).state \in {"approved", "baselined"}) /\ ~((bound_d).suspect))))) /\ (c.evidence) ELSE FALSE
Result4(w,c) == LET s0 == w
    r0 == <<>>
    s1 == [s0 EXCEPT !.items[c.item].suspect = FALSE]
    r1 == r0
    newSuspect == {s1.items[z] : z \in {i \in DOMAIN w.items: s1.items[i].suspect /\ ~w.items[i].suspect}}
    s2 == IF (((s1.releases[s1.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.next_release_required = TRUE] ELSE s1
    r2 == r1
    s3 == IF (((s2.releases[s2.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s2.releases[s2.current_release].scope))) THEN [s2 EXCEPT !.releases[s2.current_release].state = "in_preparation"] ELSE s2
    r3 == r2
 IN [world |-> s3, records |-> r3]
Enabled5(w,c) == IF c.item \in DOMAIN w.items /\ c.question \notin DOMAIN w.questions THEN (~w.next_release_required) /\ (c.actor \in {"A"}) /\ (w.items[c.item].state \in {"verified", "approved", "baselined"}) /\ (w.items[c.item].suspect) ELSE FALSE
Result5(w,c) == LET s0 == w
    r0 == <<>>
    s1 == IF Assert(("change" = "change") /\ ((s0.items[c.item]).id \in DOMAIN s0.items) /\ (s0.items[(s0.items[c.item]).id].state # "none") /\ ("T05" \in ChangeOperations) /\ (TRUE) /\ (c.question \notin DOMAIN s0.questions) /\ ("change" = "change") /\ ((s0.items[c.item]).id = (s0.items[c.item]).id) /\ ((s0.items[c.item]).version = s0.items[(s0.items[c.item]).id].version) /\ ("T05" = "T05") /\ (TRUE = TRUE) /\ ("none" = "none") /\ (FALSE = FALSE), "InputError: niespojna inicjalizacja pytania") THEN [s0 EXCEPT !.questions = (s0.questions @@ (c.question :> [state |-> "open", kind |-> "change", about |-> (s0.items[c.item]).id, about_version |-> s0.items[(s0.items[c.item]).id].version, requested_transition |-> "T05", resolution |-> "none", consumed |-> FALSE, id |-> c.question, age |-> NextAge(s0), blocking |-> TRUE]))] ELSE s0
    r1 == r0
    newSuspect == {s1.items[z] : z \in {i \in DOMAIN w.items: s1.items[i].suspect /\ ~w.items[i].suspect}}
    s2 == IF (((s1.releases[s1.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.next_release_required = TRUE] ELSE s1
    r2 == r1
    s3 == IF (((s2.releases[s2.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s2.releases[s2.current_release].scope))) THEN [s2 EXCEPT !.releases[s2.current_release].state = "in_preparation"] ELSE s2
    r3 == r2
 IN [world |-> s3, records |-> r3]
Enabled6(w,c) == IF c.item \in DOMAIN w.items THEN (~w.next_release_required) /\ (c.actor \in {"A"}) /\ (w.items[c.item].state \in {"draft"}) /\ (w.items[c.item].suspect) ELSE FALSE
Result6(w,c) == LET s0 == [w EXCEPT !.items[c.item].state = "draft"]
    r0 == <<>>
    s1 == [s0 EXCEPT !.items[c.item].suspect = FALSE]
    r1 == r0
    newSuspect == {s1.items[z] : z \in {i \in DOMAIN w.items: s1.items[i].suspect /\ ~w.items[i].suspect}}
    s2 == IF (((s1.releases[s1.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.next_release_required = TRUE] ELSE s1
    r2 == r1
    s3 == IF (((s2.releases[s2.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s2.releases[s2.current_release].scope))) THEN [s2 EXCEPT !.releases[s2.current_release].state = "in_preparation"] ELSE s2
    r3 == r2
 IN [world |-> s3, records |-> r3]
Enabled7(w,c) == IF c.question \in DOMAIN w.questions THEN (~w.next_release_required) /\ (c.actor \in {"A"}) /\ (w.questions[c.question].state \in {"open"}) /\ (((Cardinality({z \in DOMAIN w.questions: w.questions[z].state = "asked"}) = 0) /\ (w.questions[c.question] = SelectQuestion(w, "open", FALSE)))) ELSE FALSE
Result7(w,c) == LET s0 == [w EXCEPT !.questions[c.question].state = "asked"]
    r0 == <<>>
    newSuspect == {s0.items[z] : z \in {i \in DOMAIN w.items: s0.items[i].suspect /\ ~w.items[i].suspect}}
    s1 == IF (((s0.releases[s0.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s0.releases[s0.current_release].scope))) THEN [s0 EXCEPT !.next_release_required = TRUE] ELSE s0
    r1 == r0
    s2 == IF (((s1.releases[s1.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s1.releases[s1.current_release].scope))) THEN [s1 EXCEPT !.releases[s1.current_release].state = "in_preparation"] ELSE s1
    r2 == r1
 IN [world |-> s2, records |-> r2]
Enabled8(w,c) == IF c.question \in DOMAIN w.questions THEN (~w.next_release_required) /\ (c.actor \in {"U"}) /\ (w.questions[c.question].state \in {"asked"}) /\ (c.unambiguous) /\ (c.evidence) ELSE FALSE
Result8(w,c) == LET s0 == [w EXCEPT !.questions[c.question].state = "resolved"]
    r0 == <<>>
    s1 == [s0 EXCEPT !.questions[c.question].resolution = "rejected"]
    r1 == r0
    s2 == s1
    r2 == Append(r1, [kind |-> "decision", id |-> "SIM_DEC", question |-> s1.questions[c.question].id, quote |-> "SIM_QUOTE", simulation |-> TRUE, resolution |-> s1.questions[c.question].resolution, about |-> s1.questions[c.question].about, about_version |-> s1.questions[c.question].about_version, requested_transition |-> s1.questions[c.question].requested_transition])
    newSuspect == {s2.items[z] : z \in {i \in DOMAIN w.items: s2.items[i].suspect /\ ~w.items[i].suspect}}
    s3 == IF (((s2.releases[s2.current_release]).state = "accepted") /\ (\E bound_e \in newSuspect: ((bound_e).id \in s2.releases[s2.current_release].scope))) THEN [s2 EXCEPT !.next_release_required = TRUE] ELSE s2
    r3 == r2
    s4 == IF (((s3.releases[s3.current_release]).state \in {"ready", "reviewed"}) /\ (\E bound_e \in newSuspect: ((bound_e).id \in s3.releases[s3.current_release].scope))) THEN [s3 EXCEPT !.releases[s3.current_release].state = "in_preparation"] ELSE s3
    r4 == r3
 IN [world |-> s4, records |-> r4]
RawEnabled(w,c) == CASE c.operation = 0 -> Enabled0(w,c)
 [] c.operation = 1 -> Enabled1(w,c)
 [] c.operation = 2 -> Enabled2(w,c)
 [] c.operation = 3 -> Enabled3(w,c)
 [] c.operation = 4 -> Enabled4(w,c)
 [] c.operation = 5 -> Enabled5(w,c)
 [] c.operation = 6 -> Enabled6(w,c)
 [] c.operation = 7 -> Enabled7(w,c)
 [] c.operation = 8 -> Enabled8(w,c)
 [] OTHER -> FALSE
RawResult(w,c) == CASE c.operation = 0 -> Result0(w,c)
 [] c.operation = 1 -> Result1(w,c)
 [] c.operation = 2 -> Result2(w,c)
 [] c.operation = 3 -> Result3(w,c)
 [] c.operation = 4 -> Result4(w,c)
 [] c.operation = 5 -> Result5(w,c)
 [] c.operation = 6 -> Result6(w,c)
 [] c.operation = 7 -> Result7(w,c)
 [] c.operation = 8 -> Result8(w,c)
Before == <<[current_release |-> 1, items |-> [a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> TRUE, type |-> "AT", version |-> 1], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "AT", version |-> 1], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> TRUE, type |-> "CODE", version |-> 1], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "DES", version |-> 1], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "PLAN", version |-> 1], r1 |-> [depends_on |-> {"p1"}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "REQ", version |-> 2], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "REQ", version |-> 1], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]], next_release_required |-> FALSE, questions |-> [q0 |-> [about |-> "r1", about_version |-> 1, age |-> 1, blocking |-> TRUE, consumed |-> TRUE, id |-> "q0", kind |-> "change", requested_transition |-> "T05", resolution |-> "approved", state |-> "resolved"], q1 |-> [about |-> "a1", about_version |-> 1, age |-> 2, blocking |-> TRUE, consumed |-> FALSE, id |-> "q1", kind |-> "change", requested_transition |-> "T05", resolution |-> "none", state |-> "asked"]], releases |-> ((1 :> [acceptance |-> "__null__", number |-> 1, scope |-> {"a1", "a2", "c1", "d1", "p1", "r1", "r2"}, snapshot |-> "__null__", state |-> "in_preparation"]))]>>
Commands == <<[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "none", operation |-> 8, question |-> "q1", resolution |-> "approved", unambiguous |-> TRUE]>>
ExpectedEnabled == <<TRUE>>
ExpectedResult == <<[records |-> <<[about |-> "a1", about_version |-> 1, id |-> "SIM_DEC", kind |-> "decision", question |-> "q1", quote |-> "SIM_QUOTE", requested_transition |-> "T05", resolution |-> "approved", simulation |-> TRUE]>>, world |-> [current_release |-> 1, items |-> [a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> TRUE, type |-> "AT", version |-> 1], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "AT", version |-> 1], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> TRUE, type |-> "CODE", version |-> 1], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "DES", version |-> 1], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "PLAN", version |-> 1], r1 |-> [depends_on |-> {"p1"}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "REQ", version |-> 2], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "baselined", suspect |-> FALSE, type |-> "REQ", version |-> 1], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]], next_release_required |-> FALSE, questions |-> [q0 |-> [about |-> "r1", about_version |-> 1, age |-> 1, blocking |-> TRUE, consumed |-> TRUE, id |-> "q0", kind |-> "change", requested_transition |-> "T05", resolution |-> "approved", state |-> "resolved"], q1 |-> [about |-> "a1", about_version |-> 1, age |-> 2, blocking |-> TRUE, consumed |-> FALSE, id |-> "q1", kind |-> "change", requested_transition |-> "T05", resolution |-> "approved", state |-> "resolved"]], releases |-> ((1 :> [acceptance |-> "__null__", number |-> 1, scope |-> {"a1", "a2", "c1", "d1", "p1", "r1", "r2"}, snapshot |-> "__null__", state |-> "in_preparation"]))]]>>
VARIABLES case_id, phase, world, records
Init == \E i \in 1..1: /\ case_id = i /\ phase = 0 /\ world = Before[i] /\ records = <<>>
Next == /\ phase = 0 /\ RawEnabled(world, Commands[case_id])
        /\ LET result == RawResult(world, Commands[case_id]) IN /\ world' = result.world /\ records' = result.records
        /\ phase' = 1 /\ UNCHANGED case_id
Availability == (phase = 0) => (RawEnabled(world, Commands[case_id]) = ExpectedEnabled[case_id])
Successor == (phase = 1) => ([world |-> world, records |-> records] = ExpectedResult[case_id])
====
