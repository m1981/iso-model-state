# E3.4 — wynik badania

Status: verification_failed. Bez odbioru E3.

Przebiegi TLC: 79. Klasyfikacja: {'passed': 41, 'tool_error': 1, 'invariant_violation': 37}.

Baza: 19797 stanów, 38340 krawędzi; granice {'questions': 13006, 'depth': 586}.
Macierz: 58 prób semantycznych + 2 błędy wejścia; mutanty 34/34.

Pełne stany, wyjścia, wyniki narzędzi i źródła: evidence.json.
