# E3.4 — wynik badania

Status: verification_failed. Bez odbioru E3.

Przebiegi TLC: 79. Klasyfikacja: {'tool_error': 79}.

Baza: None stanów, None krawędzi; granice None.
Macierz: 58 prób semantycznych + 2 błędy wejścia; mutanty 0/34.

Pełne stany, wyjścia, wyniki narzędzi i źródła: evidence.json.
