---- MODULE Catalog ----
EXTENDS Integers, Sequences
Types == [AT |-> [depends_on |-> {"REQ"}, requires_approval |-> TRUE], CODE |-> [depends_on |-> {"AT", "DES"}, requires_approval |-> FALSE], DES |-> [depends_on |-> {"REQ"}, requires_approval |-> FALSE], PLAN |-> [depends_on |-> {}, requires_approval |-> TRUE], REQ |-> [depends_on |-> {"PLAN"}, requires_approval |-> TRUE]]
Seed == [a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "CODE", version |-> 0], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "DES", version |-> 0], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "PLAN", version |-> 0], r1 |-> [depends_on |-> {"p1"}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]]
Subjects == {"p1", "r1"}
NoneRecord == [depends_on |-> {}, id |-> "none", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "none", version |-> 0]
GraphAcyclic == TRUE
Lookup(world, id) == IF id = "none" THEN NoneRecord ELSE world[id]
Deps(e, world) == {world[id] : id \in e.depends_on}
DependencyTypesOK(world,e,ids) == /\ ids \subseteq DOMAIN world /\ {world[id].type : id \in ids} = Types[e.type].depends_on
Op0(before, after, command) ==
    /\ command.actor \in {"A"}
    /\ before[command.item].state \in {"none"}
    /\ ((DependencyTypesOK(before, before[command.item], before[command.item].depends_on) /\ GraphAcyclic) /\ (("none" = "none") \/ (((Lookup(before, "none").state = "superseded") /\ (Lookup(before, "none").type = before[command.item].type)) /\ ~((Lookup(before, "none").id = before[command.item].id)))))
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "draft"]
                   s1 == [s0 EXCEPT !.predecessor = "none"]
               IN s1]
Op1(before, after, command) ==
    /\ command.actor \in {"A"}
    /\ before[command.item].state \in {"draft"}
    /\ ((~(before[command.item].suspect) /\ command.checks) /\ (\A dep \in Deps(before[command.item], before): (dep.state \in {"approved", "baselined"})))
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "verified"]
               IN s0]
Op2(before, after, command) ==
    /\ command.actor \in {"U"}
    /\ before[command.item].state \in {"verified"}
    /\ (Types[before[command.item].type].requires_approval /\ ~(before[command.item].suspect))
    /\ command.evidence
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "approved"]
               IN s0]
Op3(before, after, command) ==
    /\ command.actor \in {"U"}
    /\ before[command.item].state \in {"verified"}
    /\ (before[command.item].rejections < 2)
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "draft"]
                   s1 == [s0 EXCEPT !.rejections = (s0.rejections + 1)]
               IN s1]
Op4(before, after, command) ==
    /\ command.actor \in {"U"}
    /\ before[command.item].state \in {"approved", "verified"}
    /\ ((~(before[command.item].suspect) /\ ((before[command.item].state = "approved") \/ ~(Types[before[command.item].type].requires_approval))) /\ (\A dep \in Deps(before[command.item], before): (dep.state = "baselined")))
    /\ command.evidence
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "baselined"]
               IN s0]
RawAction(before,after,command) == CASE command.operation = 0 -> Op0(before,after,command)
    [] command.operation = 1 -> Op1(before,after,command)
    [] command.operation = 2 -> Op2(before,after,command)
    [] command.operation = 3 -> Op3(before,after,command)
    [] command.operation = 4 -> Op4(before,after,command)
    [] OTHER -> FALSE
Commands == <<[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 0]>>
ExpectedStates == <<[a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "CODE", version |-> 0], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "DES", version |-> 0], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "PLAN", version |-> 0], r1 |-> [depends_on |-> {"p1"}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]],
[a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "CODE", version |-> 0], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "DES", version |-> 0], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "PLAN", version |-> 0], r1 |-> [depends_on |-> {"p1"}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "draft", suspect |-> FALSE, type |-> "REQ", version |-> 0], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]]>>
VARIABLES items, depth
Init == /\ items = Seed /\ depth = 0
Next == /\ depth < Len(Commands) /\ RawAction(items,items',Commands[depth+1]) /\ depth' = depth+1
Availability == (depth < Len(Commands)) => ENABLED Next
Successor == items = ExpectedStates[depth+1]
====
