---- MODULE Catalog ----
EXTENDS Integers, Sequences
Types == [AT |-> [depends_on |-> {"REQ"}, requires_approval |-> TRUE], CODE |-> [depends_on |-> {"AT", "DES"}, requires_approval |-> FALSE], DES |-> [depends_on |-> {"REQ"}, requires_approval |-> FALSE], PLAN |-> [depends_on |-> {}, requires_approval |-> TRUE], REQ |-> [depends_on |-> {"PLAN"}, requires_approval |-> TRUE]]
Seed == [a1 |-> [depends_on |-> {"r1"}, id |-> "a1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], a2 |-> [depends_on |-> {"r2"}, id |-> "a2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "AT", version |-> 0], c1 |-> [depends_on |-> {"a1", "d1"}, id |-> "c1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "CODE", version |-> 0], d1 |-> [depends_on |-> {"r1"}, id |-> "d1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "DES", version |-> 0], p1 |-> [depends_on |-> {}, id |-> "p1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "PLAN", version |-> 0], r1 |-> [depends_on |-> {}, id |-> "r1", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r2 |-> [depends_on |-> {"p1"}, id |-> "r2", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0], r3 |-> [depends_on |-> {"p1"}, id |-> "r3", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "REQ", version |-> 0]]
Subjects == {"p1", "r1"}
NoneRecord == [depends_on |-> {}, id |-> "none", predecessor |-> "none", rejections |-> 0, state |-> "none", suspect |-> FALSE, type |-> "none", version |-> 0]
GraphAcyclic == TRUE
Lookup(world, id) == IF id = "none" THEN NoneRecord ELSE world[id]
Deps(e, world) == {world[id] : id \in e.depends_on}
DependencyTypesOK(world,e,ids) == /\ ids \subseteq DOMAIN world /\ {world[id].type : id \in ids} = Types[e.type].depends_on
Op0(before, after, command) ==
    /\ command.actor \in {"A"}
    /\ before[command.item].state \in {"none"}
    /\ ((TRUE /\ GraphAcyclic) /\ (("none" = "none") \/ (((Lookup(before, "none").state = "superseded") /\ (Lookup(before, "none").type = before[command.item].type)) /\ ~((Lookup(before, "none").id = before[command.item].id)))))
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "draft"]
                   s1 == [s0 EXCEPT !.version = 1]
                   s2 == [s1 EXCEPT !.predecessor = "none"]
               IN s2]
Op1(before, after, command) ==
    /\ command.actor \in {"A"}
    /\ before[command.item].state \in {"draft"}
    /\ ((~(before[command.item].suspect) /\ command.checks) /\ (\A dep \in Deps(before[command.item], before): (dep.state \in {"approved", "baselined"})))
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "verified"]
               IN s0]
Op2(before, after, command) ==
    /\ command.actor \in {"U"}
    /\ before[command.item].state \in {"verified"}
    /\ (Types[before[command.item].type].requires_approval /\ ~(before[command.item].suspect))
    /\ command.evidence
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "approved"]
               IN s0]
Op3(before, after, command) ==
    /\ command.actor \in {"U"}
    /\ before[command.item].state \in {"verified"}
    /\ (before[command.item].rejections < 2)
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "draft"]
                   s1 == [s0 EXCEPT !.rejections = (s0.rejections + 1)]
               IN s1]
Op4(before, after, command) ==
    /\ command.actor \in {"U"}
    /\ before[command.item].state \in {"approved", "verified"}
    /\ ((~(before[command.item].suspect) /\ ((before[command.item].state = "approved") \/ ~(Types[before[command.item].type].requires_approval))) /\ (\A dep \in Deps(before[command.item], before): (dep.state = "baselined")))
    /\ command.evidence
    /\ after = [before EXCEPT ![command.item] = LET s0 == [before[command.item] EXCEPT !.state = "baselined"]
               IN s0]
RawAction(before,after,command) == CASE command.operation = 0 -> Op0(before,after,command)
    [] command.operation = 1 -> Op1(before,after,command)
    [] command.operation = 2 -> Op2(before,after,command)
    [] command.operation = 3 -> Op3(before,after,command)
    [] command.operation = 4 -> Op4(before,after,command)
    [] OTHER -> FALSE

RefDependencyTypes == [kind \in {"PLAN", "REQ", "AT", "DES", "CODE"} |->
    CASE kind = "PLAN" -> {}
      [] kind = "REQ" -> {"PLAN"}
      [] kind = "AT" -> {"REQ"}
      [] kind = "DES" -> {"REQ"}
      [] kind = "CODE" -> {"DES", "AT"}]
RefApprovalTypes == {"PLAN", "REQ", "AT"}
RefAcyclic == TRUE
RefBudget == 2
RefInitialVersion == 1

RefTypeOK(before, record) ==
    /\ record.type \in DOMAIN RefDependencyTypes
    /\ record.depends_on \subseteq DOMAIN before
    /\ {before[d].type : d \in record.depends_on} = RefDependencyTypes[record.type]

ExpectedEnabled(before, command) ==
    LET record == before[command.item]
        mature == \A d \in record.depends_on : before[d].state \in {"approved", "baselined"}
        baseline == \A d \in record.depends_on : before[d].state = "baselined"
    IN CASE command.operation = 0 ->
                /\ record.state = "none"
                /\ command.actor = "A"
                /\ RefTypeOK(before, record)
                /\ RefAcyclic
         [] command.operation = 1 ->
                /\ record.state = "draft"
                /\ command.actor = "A"
                /\ ~record.suspect
                /\ command.checks
                /\ mature
         [] command.operation = 2 ->
                /\ record.state = "verified"
                /\ command.actor = "U"
                /\ record.type \in RefApprovalTypes
                /\ ~record.suspect
                /\ command.evidence
         [] command.operation = 3 ->
                /\ record.state = "verified"
                /\ command.actor = "U"
                /\ record.rejections < RefBudget
         [] command.operation = 4 ->
                /\ record.state \in {"approved", "verified"}
                /\ command.actor = "U"
                /\ ~record.suspect
                /\ (record.state = "approved" \/ record.type \notin RefApprovalTypes)
                /\ baseline
                /\ command.evidence
         [] OTHER -> FALSE

ExpectedAction(before, after, command) ==
    LET record == before[command.item]
        replacement == CASE command.operation = 0 ->
                               [record EXCEPT !.state = "draft", !.version = RefInitialVersion, !.predecessor = "none"]
                         [] command.operation = 1 -> [record EXCEPT !.state = "verified"]
                         [] command.operation = 2 -> [record EXCEPT !.state = "approved"]
                         [] command.operation = 3 ->
                               [record EXCEPT !.state = "draft", !.rejections = record.rejections + 1]
                         [] command.operation = 4 -> [record EXCEPT !.state = "baselined"]
                         [] OTHER -> record
    IN /\ ExpectedEnabled(before, command)
       /\ after = [before EXCEPT ![command.item] = replacement]

Commands == <<[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 0],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 0],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 0],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 0],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 0],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 0],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 0],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 0],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 0],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 0],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 0],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 0],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 1],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 1],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 1],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 1],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 1],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 1],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 1],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 1],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 1],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 1],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 1],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 1],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 2],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 2],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 2],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 2],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 2],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 2],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 2],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 2],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 2],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 2],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 2],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 2],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 3],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 3],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 3],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 3],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 3],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 3],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 3],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 3],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 3],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 3],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 3],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 3],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 4],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 4],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 4],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 4],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 4],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 4],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 4],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 4],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "p1", operation |-> 4],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "p1", operation |-> 4],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "p1", operation |-> 4],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "p1", operation |-> 4],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 0],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 0],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 0],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 0],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 0],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 0],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 0],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 0],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 0],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 0],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 0],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 0],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 1],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 1],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 1],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 1],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 1],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 1],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 1],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 1],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 1],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 1],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 1],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 1],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 2],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 2],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 2],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 2],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 2],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 2],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 2],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 2],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 2],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 2],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 2],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 2],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 3],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 3],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 3],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 3],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 3],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 3],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 3],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 3],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 3],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 3],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 3],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 3],
[actor |-> "A", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 4],
[actor |-> "A", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 4],
[actor |-> "A", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 4],
[actor |-> "A", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 4],
[actor |-> "R", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 4],
[actor |-> "R", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 4],
[actor |-> "R", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 4],
[actor |-> "R", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 4],
[actor |-> "U", checks |-> FALSE, evidence |-> FALSE, item |-> "r1", operation |-> 4],
[actor |-> "U", checks |-> FALSE, evidence |-> TRUE, item |-> "r1", operation |-> 4],
[actor |-> "U", checks |-> TRUE, evidence |-> FALSE, item |-> "r1", operation |-> 4],
[actor |-> "U", checks |-> TRUE, evidence |-> TRUE, item |-> "r1", operation |-> 4]>>
MaxDepth == 16
VARIABLES items, depth, used, verified, approved, ok
Init == /\ items = Seed /\ depth = 0 /\ used = [i \in Subjects |-> 0] /\ verified = {} /\ approved = {} /\ ok = TRUE
Next == /\ depth < MaxDepth
        /\ \E k \in DOMAIN Commands:
              /\ RawAction(items, items', Commands[k]) /\ depth' = depth + 1
              /\ used' = IF Commands[k].operation = 3 THEN [used EXCEPT ![Commands[k].item] = @ + 1] ELSE used
              /\ verified' = verified \cup (IF Commands[k].operation = 1 /\ items'[Commands[k].item].state = "verified" THEN {Commands[k].item} ELSE {})
              /\ approved' = approved \cup (IF Commands[k].operation = 2 /\ items'[Commands[k].item].state = "approved" THEN {Commands[k].item} ELSE {})
              /\ ok' = ExpectedAction(items, items', Commands[k])
Availability == (depth < MaxDepth) => (\A k \in DOMAIN Commands: (ENABLED RawAction(items, items', Commands[k])) = ExpectedEnabled(items, Commands[k]))
Successor == ok
HistoryBudget == \A i \in Subjects: used[i] <= RefBudget
CounterHistory == \A i \in Subjects: items[i].rejections = used[i]
VerifiedHistory == \A i \in Subjects: (items[i].state \in {"approved","baselined"}) => i \in verified
ApprovedHistory == \A i \in Subjects: (items[i].state = "baselined" /\ items[i].type \in RefApprovalTypes) => i \in approved
CreatedVersion == \A i \in Subjects: (items[i].state # "none") => items[i].version = RefInitialVersion
====
